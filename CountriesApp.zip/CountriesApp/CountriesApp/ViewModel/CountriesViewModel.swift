//
//  CountriesViewModel.swift
//  CountriesApp
//
//  Created by Macbook Pro on 16/06/25.
//

import Foundation

protocol CountriesViewModelDelegate: AnyObject {
    func didUpdateCountries()
    func didFail(with error: CountryError)
}

final class CountriesViewModel {
    private let service: CountryServiceProtocol
    private(set) var allCountries: [Country] = []
    private(set) var filteredCountries: [Country] = []

    weak var delegate: CountriesViewModelDelegate?

    init(service: CountryServiceProtocol) {
        self.service = service
    }

    func fetchCountries() {
        service.fetchCountries { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let list):
                    self?.allCountries = list
                    self?.filteredCountries = list
                    self?.delegate?.didUpdateCountries()
                case .failure(let error):
                    self?.delegate?.didFail(with: error)
                }
            }
        }
    }

    func filterCountries(by query: String) {
        guard !query.isEmpty else {
            filteredCountries = allCountries
            delegate?.didUpdateCountries()
            return
        }

        filteredCountries = allCountries.filter {
            $0.name.localizedCaseInsensitiveContains(query) ||
            ($0.capital?.localizedCaseInsensitiveContains(query) ?? false)
        }

        delegate?.didUpdateCountries()
    }

    func numberOfCountries() -> Int {
        return filteredCountries.count
    }

    func country(at index: Int) -> Country {
        return filteredCountries[index]
    }
}
