//
//  CountryTableViewCell.swift
//  CountriesApp
//
//  Created by Macbook Pro on 16/06/25.
//

import UIKit

class CountryTableViewCell: UITableViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var codeLabel: UILabel!
    @IBOutlet weak var capitalLabel: UILabel!

    static let reuseIdentifier = "CountryCell"

    override func awakeFromNib() {
        super.awakeFromNib()

        titleLabel.font = UIFont.preferredFont(forTextStyle: .body)
        titleLabel.textColor = .label
        titleLabel.adjustsFontForContentSizeCategory = true

        codeLabel.font = UIFont.preferredFont(forTextStyle: .footnote)
        codeLabel.textColor = .secondaryLabel
        codeLabel.textAlignment = .right
        codeLabel.adjustsFontForContentSizeCategory = true

        capitalLabel.font = UIFont.preferredFont(forTextStyle: .subheadline)
        capitalLabel.textColor = .tertiaryLabel
        capitalLabel.adjustsFontForContentSizeCategory = true

        // Add rounded corners and shadow for card-like effect
        contentView.layer.cornerRadius = 10
        contentView.layer.masksToBounds = true

        let bgView = UIView()
        bgView.backgroundColor = .systemBackground
        bgView.layer.cornerRadius = 10
        bgView.layer.shadowColor = UIColor.black.cgColor
        bgView.layer.shadowOpacity = 0.1
        bgView.layer.shadowOffset = CGSize(width: 0, height: 1)
        bgView.layer.shadowRadius = 3
        backgroundView = bgView
    }

    override func layoutSubviews() {
        super.layoutSubviews()

        let horizontalInset: CGFloat = 12
        let verticalInset: CGFloat = 6
        contentView.frame = contentView.frame.inset(by: UIEdgeInsets(top: verticalInset, left: horizontalInset, bottom: verticalInset, right: horizontalInset))
    }

    func configure(with country: Country) {
        titleLabel.text = "\(country.name), \(country.region)"
        codeLabel.text = country.code.uppercased()

        if let capital = country.capital, !capital.isEmpty {
            capitalLabel.text = capital
        } else {
            capitalLabel.text = "No capital available"
            capitalLabel.textColor = .systemGray2
        }
    }
}
