//
//  CountryService.swift
//  CountriesApp
//
//  Created by Macbook Pro on 16/06/25.
//

import Foundation

protocol CountryServiceProtocol {
    func fetchCountries(completion: @escaping (Result<[Country], CountryError>) -> Void)
}

enum CountryError: Error {
    case network(Error)
    case decoding(Error)
    case emptyData
}

final class CountryService: CountryServiceProtocol {
    private let url = URL(string: "https://gist.githubusercontent.com/peymano-wmt/32dcb892b06648910ddd40406e37fdab/raw/db25946fd77c5873b0303b858e861ce724e0dcd0/countries.json")!

    func fetchCountries(completion: @escaping (Result<[Country], CountryError>) -> Void) {
        URLSession.shared.dataTask(with: url) { data, resp, err in
            if let err = err {
                return completion(.failure(.network(err)))
            }
            guard let data = data else {
                return completion(.failure(.emptyData))
            }
            do {
                let list = try JSONDecoder().decode([Country].self, from: data)
                completion(.success(list))
            } catch {
                completion(.failure(.decoding(error)))
            }
        }
        .resume()
    }
}
