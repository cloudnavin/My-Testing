//
//  CountriesViewController.swift
//  CountriesApp
//
//  Created by Macbook Pro on 16/06/25.
//

import UIKit

class CountriesViewController: UIViewController, UITableViewDelegate {
    @IBOutlet weak var tableView: UITableView!

    private lazy var searchController: UISearchController = {
        let sc = UISearchController(searchResultsController: nil)
        sc.searchResultsUpdater = self
        sc.obscuresBackgroundDuringPresentation = false
        sc.searchBar.placeholder = "Search by name or capital"
        return sc
    }()
    
    var viewModel: CountriesViewModel!

    override func viewDidLoad() {
        super.viewDidLoad()
        assert(viewModel != nil, "ViewModel must be injected before view is loaded")
        viewModel.delegate = self
        setupTableView()
        navigationItem.searchController = searchController
        viewModel.fetchCountries()
    }

    private func setupTableView() {
        let nib = UINib(nibName: "CountryTableViewCell", bundle: nil)
        tableView.register(nib, forCellReuseIdentifier: CountryTableViewCell.reuseIdentifier)
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 80
        tableView.delegate = self
        tableView.dataSource = self
    }

    private func showError(_ error: CountryError) {
        let alert = UIAlertController(title: "Oops", message: error.localizedDescription, preferredStyle: .alert)
        alert.addAction(.init(title: "OK", style: .default))
        present(alert, animated: true)
    }
}

// MARK: - ViewModel Binding
extension CountriesViewController: CountriesViewModelDelegate {
    func didUpdateCountries() {
        tableView.reloadData()
    }

    func didFail(with error: CountryError) {
        showError(error)
    }
}

// MARK: - Table Data Source
extension CountriesViewController: UITableViewDataSource {
    func tableView(_ tv: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.numberOfCountries()
    }

    func tableView(_ tv: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tv.dequeueReusableCell(withIdentifier: CountryTableViewCell.reuseIdentifier, for: indexPath)
        guard let cell = cell as? CountryTableViewCell else { return cell }
        let country = viewModel.country(at: indexPath.row)
        cell.configure(with: country)
        return cell
    }
}

// MARK: - UISearchResultsUpdating
extension CountriesViewController: UISearchResultsUpdating {
    func updateSearchResults(for searchController: UISearchController) {
        viewModel.filterCountries(by: searchController.searchBar.text ?? "")
    }
}
