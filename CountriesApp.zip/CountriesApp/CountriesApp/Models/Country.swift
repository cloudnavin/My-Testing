//
//  Country.swift
//  CountriesApp
//
//  Created by Macbook Pro on 16/06/25.
//

struct Country: Decodable {
    let name: String
    let region: String
    let code: String
    let capital: String?
}
